function x ( )
x = 7
if < x 4
print ( x )
else
print ( * x 2 )
end
end
